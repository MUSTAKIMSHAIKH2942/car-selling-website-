<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <script src="https://kit.fontawesome.com/610aca874a.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
    <style>
.grid-container {
  
  grid-template-columns: auto auto auto;
  background-color: #2196F3;
  padding: 10px;
  
}
.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.8);
  padding: 20px;
  font-size: 20px;
  text-align: left;
}
</style>
</head>

<body>
   
<h1 class="heading"><i class="fas fa-car"></i> login <span>form</span> </h1>
      
    

   <section>
   <div class="grid-container">
   <div class="grid-item">
   <i class="fas fa-user"></i><h2>Enter username and password</h2><br>
    <form action="validation.php" method="post">
               <label for="username">Username</label><br>
               <input type="text " placeholder="user name" class=" box " name="user"required/><br></br>
               <label for="fname">password</label><br>
               <input type="password " placeholder="password " class="box " name="password"required> <br>               
                <input type="submit" value="login" class="btn" >
            
            </form>  
           <i class="fas fa-users"></i>    <h2>create an account</h2>
        
       <div >
    <form action="registration.php" method="post">
               <label for="username">Username</label><br>
               <input type="text " placeholder="user name" class=" box " name="user"required/><br></br>
               <label for="fname">password</label><br>
               <input type="password " placeholder="password " class="box " name="password"required> <br>               
                <input type="submit" value="submit" class="btn" >
      </form>
   </div>
  </div>
</div>
   </section>


   


  


    <section class="footer " id="footer ">

        <div class="box-container ">

            <div class="box ">
                <h3>our branches</h3>
                <a href="# "> <i class="fas fa-map-marked "></i> </i> India </a>
                <a href="index.html"> <i class="fas fa-arrow-right "></i> official website</a>

             

            </div>



            <div class=" box ">
                <h3>contact info</h3>
                <a href="# "> <i class="fas fa-phone "></i> 9970733622</a>
                <a href="# "> <i class="fas fa-phone "></i> 9359768168 </a>
                <a href="# "> <i class="fas fa-envelope "></i> skmusu17@gmail.com </a>
                <a href="# "> <i class="fas fa-map-marker-alt "></i> jalgaon, india - 425202 </a>
            </div>

            <div class="box ">
                <h3>contact info</h3>
                <a href="# "> <i class="fab fa-facebook-f "></i> facebook </a>
                <a href="# "> <i class="fab fa-twitter "></i> twitter </a>
                <a href="# "> <i class="fab fa-instagram "></i> instagram </a>
                <a href="# "> <i class="fab fa-linkedin "></i> linkedin </a>

            </div>

        </div>

        <div class="credit "> created by mohd,mustakim shaikh</div>

    </section>

    </header>
</body>

</html>
<?php


    if(isset($_POST['submit'])){

        $email = $_SESSION['email']-$_POST['email'];
        $pwd = $_POST['password'];
        $sql="select from register where email '$email";

        $run= mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($run);
        $pwd_fetch=$row['password'];
        $pwd_decode= password_verify($pwd, $pwd_fetch);

        if($pwd_decode){
        echo "<script>window.open('admin.php?success-Login successfully', '_self')</script>";
        } else{
        echo "<script>window.open('index.php?error-Username or password is incorrect', '_self')</script>";

        }
    }
?>
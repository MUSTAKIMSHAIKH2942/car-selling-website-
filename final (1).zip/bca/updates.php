<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- font awesome kitcode link -->
 <script src="https://kit.fontawesome.com/610aca874a.js" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>admin</title>
</head>



<body>
<section class="Our services" id="Our services">

<h1 class="heading"> list of customer <span> who response.</span> </h1>


  
     <div class ="tabel-responsive">
         <table>
             <thead>
                 <tr>'
                     <th>name</th>
                     <th>email</th>
                     <th>contact</th>
                     <th>subject</th>
                     <th colspan="2">operation</th>
                 </tr>
             </thead>
             <tbody>
             <?php
  
           include 'back.php';
  

             $selectquery = "select * from customer";  
            $query = mysqli_query($con,$selectquery); 
            $nums = mysqli_num_rows($query);
            while($res = mysqli_fetch_array($query)){
              
              ?>
              <tr>
              <td><?php echo $res['name'];?></td>
              <td> <?php echo $res['email'];?></td>
              <td><?php echo $res['contact'];?></td>
              <td><?php echo $res['subject'];?></td>
              <td><a href="#" data-toggle="tooltip" data-placement="top" title="update"><i class="fas fa-edit" aria-hidden="true"></i></a></td>
              <td><a href="#" data-toggle="tooltip" data-placement="top" title="delete"><i class="fas fa-trash"aria-hidden="true"></i></a></td>
         </tr>
        <?php    
        }
         ?>
            
        
             </tbody>
         </table>
     </div>  
     <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script> 
    </body>
</html>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <!-- font awesome kitcode link -->
    <script src="https://kit.fontawesome.com/610aca874a.js" crossorigin="anonymous"></script>



    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<header class="header">

<div id="menu-btn" class="fas fa-bars"></div>

<a href="#" class="logo"> <i class="fas fa-user-tie"></i><span>Four</span>wheels </a>

<nav class="navbar">
    <a href="#home"><i class="fas fa-home "></i>home</a>
    <a href="#Our services"><i class="fas fa-concierge-bell"></i>Our services</a>
    <a href="#Available cars"><i class="fas fa-car"></i>Available cars</a>
    <a href="#contact"><i class="fas fa-address-book"></i>contact</a>
    <a href="login.php" class="btn "> login</a>
    <a href="logout.php" class="btn "> logout</a>
    

</header>

    <section class="home" id="home">

        
        <h3 data-speed="-2" class="home-parallax">Find your car </h3>
        <img data-speed="5" class="home-parallax" src="image/car123.webp" alt="">
     
        
    </section>



    <section class="icons-container">

        <div class="icons">
            <i class="fas fa-home"></i>
            <div class="content">
                <h3>1+</h3>
                <p>branches</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-car"></i>
            <div class="content">
                <h3>4770+</h3>
                <p>cars sold</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-users"></i>
            <div class="content">
                <h3>320+</h3>
                <p>happy clients</p>
            </div>
        </div>

        <div class="icons">
            <i class="fas fa-car"></i>
            <div class="content">
                <h3>1500+</h3>
                <p>news cars</p>
            </div>
        </div>

    </section>



  

    <section class="Our services" id="Our services">

        <h1 class="heading"> Our <span> services.</span> </h1>

        <div class="box-container">

            <div class="box">
                <i class="fas fa-car"></i>
                <h3>car selling</h3>
                <p>A website for selling second hand cars online. !wanna to buy a car in a sutaible price just contact us </p>

            </div>
</section>


<section class="Available " id="Available cars">

    <h1 class="heading"> <span>Available </span> cars </h1>

    <div class="box-container">

        <div class="box">

            <img src="image/car1.png" alt="car for sale" width="250" height="200">

            <h3>car for sale</h3>
            <div class="price">Rs2,45,000/-</div>
           
            <img src="image/car2.png" alt="car for sale" width="250" height="200">

            <h3>car for sale</h3>
            <div class="price">Rs 1,65,000/-</div>
            <a href="car.html " class="btn"> more cars</a>
            

        </div>
       
    </div>
   </section>
    

    <section class="contact" id="contact">

        <h1 class="heading"><span>contact</span> us</h1>

        <div class="row">

            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d70880.2147427315!2d75.53673336095999!3d20.985324107758043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd90fa4a1eab90f%3A0x37f67bd21bff0a3c!2sJalgaon%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1647153843395!5m2!1sen!2sin"
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            <!-- form   -->
            
            <form action="" method="post">
                <h3>Get in touch</h3>
                <input type="text " placeholder="Name" class=" box " name="name"required/>
                <input type="email " placeholder="your email " class="box " name="email"required/>
                <input type="tel" placeholder="contact " class="box " name="contact"required/>
                <input type="tel " placeholder="subject " class="box " name="subject"required/>
               
               

                
                <input type="submit" value="submit" class="btn" name="submit">

            </form>

        </div>

    </section>

    <section class="footer " id="footer ">

        <div class="box-container ">

            <div class="box ">
                <h3>our branches</h3>
                <a href="# "> <i class="fas fa-map-marked "></i> </i> India </a>



            </div>

            <div class="box ">
                <h3>quick links</h3>
               
                <a href="login.php"> <i class="fas fa-arrow-right "></i> login</a>
                
                

            </div>

            <div class="box ">
                <h3>contact info</h3>
                <a href="# "> <i class="fas fa-phone "></i> 9970733622</a>
                <a href="# "> <i class="fas fa-phone "></i> 9359768168 </a>
                <a href="# "> <i class="fas fa-envelope "></i> skmusu17@gmail.com </a>
                <a href="# "> <i class="fas fa-map-marker-alt "></i> jalgaon, india - 425202 </a>
            </div>

            <div class="box ">
                <h3>contact info</h3>
                <a href="# "> <i class="fab fa-facebook-f "></i> facebook </a>
                <a href="# "> <i class="fab fa-twitter "></i> twitter </a>
                <a href="# "> <i class="fab fa-instagram "></i> instagram </a>
                <a href="# "> <i class="fab fa-linkedin "></i> linkedin </a>

            </div>

        </div>

        <div class="credit "> created by mohd,mustakim shaikh</div>

    </section>
</body>
</html>
<?php
include 'back.php';
if(isset($_POST['submit'])){

$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$subject = $_POST['subject'];


$insertquery= "insert into customer(name,email,contact,subject) values('$name','$email','$contact','$subject')";

$res=mysqli_query($con,$insertquery);

if($res){
     // echo "data insert properly";
    ?>
    <script>
        alert("data inserted properly");
    </script>
        <?php
}else{
    ?>
    <script>
        alert("data not inserted ");
    </script>
        <?php
    }
}
        ?>
